from django.urls import path
from .views import customer_list,customer_details_view,order_list,order_details_view,orderitem_list,orderitem_details



urlpatterns=[
     path('customers',customer_list),
     path('customers/<int:passed_id>',customer_details_view),
     path('orders',order_list),
     path('orders/<int:passed_id>',order_details_view),
     path('order_item',orderitem_list),
     path('order_item/<int:passed_id>',orderitem_details),





]